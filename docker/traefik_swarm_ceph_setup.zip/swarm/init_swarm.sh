#!/usr/bin/env bash
docker swarm init --advertise-addr 10.10.101.2
