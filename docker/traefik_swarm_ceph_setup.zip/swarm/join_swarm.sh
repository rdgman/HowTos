#!/usr/bin/env bash
# Replace <token> and <manager_ip> with actual values
docker swarm join --token <token> <manager_ip>:2377
